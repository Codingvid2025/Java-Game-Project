package ApplianceRetrival;

public interface Appliances {
    String getBrand();
    int getPowerConsumption(); // in watts
    int getWarrantyPeriod(); // in years
}
