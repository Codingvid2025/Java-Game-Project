package ApplianceRetrival;

public interface CoolingAppliance {
    void setCoolingCapacity(int capacity);
    int getCoolingCapacity();
    void setNumberOfDoors(int doors);
    int getNumberOfDoors();
}

